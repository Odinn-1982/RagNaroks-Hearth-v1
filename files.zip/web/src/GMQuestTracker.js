import React from "react";

export default function GMQuestTracker() {
  return (
    <div className="gm-quests" style={{ padding: 8 }}>
      <h4>Quest Log</h4>
      <ul>
        <li>The Black Well - Active</li>
        <li>Find the Heirloom - Pending</li>
      </ul>
    </div>
  );
}