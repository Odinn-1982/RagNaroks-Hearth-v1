import React from "react";

export default function VoiceWidget() {
  return (
    <div className="voice-widget" style={{ marginTop: 12 }}>
      <button>Join Voice</button>
    </div>
  );
}