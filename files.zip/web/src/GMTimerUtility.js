import React from "react";

export default function GMTimerUtility() {
  return (
    <div className="gm-timers" style={{ padding: 8 }}>
      <h4>Timers</h4>
      <div>Combat: 43s left</div>
    </div>
  );
}