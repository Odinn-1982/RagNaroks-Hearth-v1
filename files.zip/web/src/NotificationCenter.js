import React from "react";

export default function NotificationCenter() {
  return (
    <div className="notifications" style={{ marginTop: 12 }}>
      <h4>Notifications</h4>
      <div>No new notifications</div>
    </div>
  );
}