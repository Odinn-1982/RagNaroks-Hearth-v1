import React from "react";
import { View, Text } from "react-native";

export default function CharacterSheetDisplay() {
  return (
    <View>
      <Text>Tharn - Barbarian - 38/52 HP</Text>
    </View>
  );
}