import React from "react";

export default function TemplateManagerPanel() {
  return (
    <div className="template-manager" style={{ marginTop: 12 }}>
      <h4>Templates</h4>
      <div>Create/Edit templates here</div>
    </div>
  );
}