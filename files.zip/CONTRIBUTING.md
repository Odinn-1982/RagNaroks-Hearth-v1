# Contributing

- Fork repo and open PRs against `main`.
- Keep changes small and test locally.
- Add tests for new behavior where appropriate.
- Run linters and formatters if present.