import React from "react";

export default function GMInitiativeTracker() {
  return (
    <div className="initiative" style={{ padding: 8 }}>
      <h4>Initiative</h4>
      <ol>
        <li>Tharn (38 HP)</li>
        <li>Elya (24 HP)</li>
      </ol>
    </div>
  );
}